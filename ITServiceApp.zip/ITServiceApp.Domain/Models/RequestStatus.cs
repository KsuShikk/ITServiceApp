﻿namespace ITServiceApp.Domain.Models
{
    public enum RequestStatus
    {
        Created,        
        InProgress,    
        WaitingForParts,
        Completed       
    }
}